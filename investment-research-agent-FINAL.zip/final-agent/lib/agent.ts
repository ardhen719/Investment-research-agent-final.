/**
 * Investment Research Agent
 * Built with LangChain.js + LangGraph.js + OpenAI GPT-4o
 * Author: Ardhendu Shekhar
 */

import { ChatOpenAI } from "@langchain/openai";
import { tool } from "@langchain/core/tools";
import { z } from "zod";
import { StateGraph, END, START, Annotation } from "@langchain/langgraph";
import { ToolNode } from "@langchain/langgraph/prebuilt";
import { BaseMessage, HumanMessage, SystemMessage } from "@langchain/core/messages";
import axios from "axios";

// State
const AgentState = Annotation.Root({
  messages: Annotation<BaseMessage[]>({
    reducer: (x, y) => x.concat(y),
    default: () => [],
  }),
});

// ─── Tool 1: Financials via Yahoo Finance (no key needed) ────────
const getFinancials = tool(
  async ({ company }: { company: string }) => {
    try {
      const searchRes = await axios.get(
        `https://query2.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(company)}&quotesCount=1`,
        { headers: { "User-Agent": "Mozilla/5.0" }, timeout: 8000 }
      );
      const quotes = searchRes.data?.quotes ?? [];
      if (!quotes.length) return `No ticker found for ${company}`;
      const ticker = quotes[0].symbol;

      const quoteRes = await axios.get(
        `https://query2.finance.yahoo.com/v10/finance/quoteSummary/${ticker}?modules=price,summaryDetail,defaultKeyStatistics`,
        { headers: { "User-Agent": "Mozilla/5.0" }, timeout: 8000 }
      );
      const result = quoteRes.data?.quoteSummary?.result?.[0];
      if (!result) return "Financial data unavailable.";

      const p = result.price ?? {};
      const s = result.summaryDetail ?? {};
      const k = result.defaultKeyStatistics ?? {};

      const fmt = (v: any) => {
        if (v?.raw == null) return "N/A";
        const n = v.raw;
        if (n > 1e12) return `$${(n / 1e12).toFixed(2)}T`;
        if (n > 1e9)  return `$${(n / 1e9).toFixed(2)}B`;
        if (n > 1e6)  return `$${(n / 1e6).toFixed(2)}M`;
        return String(n);
      };

      return [
        `Ticker: ${ticker}`,
        `Company: ${p.longName?.raw ?? company}`,
        `Market Cap: ${fmt(p.marketCap)}`,
        `Price: ${p.regularMarketPrice?.fmt ?? "N/A"} ${p.currency ?? ""}`,
        `52W High: ${fmt(s.fiftyTwoWeekHigh)}`,
        `52W Low: ${fmt(s.fiftyTwoWeekLow)}`,
        `PE Ratio (TTM): ${s.trailingPE?.fmt ?? "N/A"}`,
        `Forward PE: ${s.forwardPE?.fmt ?? "N/A"}`,
        `Profit Margin: ${k.profitMargins?.fmt ?? "N/A"}`,
        `Beta: ${s.beta?.fmt ?? "N/A"}`,
        `Sector: ${p.sector?.raw ?? "N/A"}`,
        `Exchange: ${p.exchangeName?.raw ?? "N/A"}`,
      ].join("\n");
    } catch (e: any) {
      return `Financial data error: ${e.message}`;
    }
  },
  {
    name: "get_financials",
    description: "Fetch real financial data: market cap, revenue, PE ratio, margins, beta for a public company.",
    schema: z.object({ company: z.string() }),
  }
);

// ─── Tool 2: Web Search via SerpAPI ─────────────────────────────
const searchWeb = tool(
  async ({ query }: { query: string }) => {
    const serpKey = process.env.SERPAPI_KEY;
    if (!serpKey) return `[No SERPAPI_KEY] Simulated search for: ${query}`;
    try {
      const res = await axios.get("https://serpapi.com/search", {
        params: { q: query, api_key: serpKey, num: 5, engine: "google" },
        timeout: 10000,
      });
      const results = res.data?.organic_results ?? [];
      if (!results.length) return "No results found.";
      return results.slice(0, 5).map((r: any) => `- ${r.title}: ${r.snippet}`).join("\n");
    } catch (e: any) {
      return `Search error: ${e.message}`;
    }
  },
  {
    name: "search_web",
    description: "Search for business model, strategy, competitors, leadership, market position.",
    schema: z.object({ query: z.string() }),
  }
);

// ─── Tool 3: News ────────────────────────────────────────────────
const getNews = tool(
  async ({ company }: { company: string }) => {
    const serpKey = process.env.SERPAPI_KEY;
    if (!serpKey) return `[No SERPAPI_KEY] Simulated news for: ${company}`;
    try {
      const res = await axios.get("https://serpapi.com/search", {
        params: { q: `${company} latest news 2025`, api_key: serpKey, num: 5, engine: "google", tbm: "nws" },
        timeout: 10000,
      });
      const results = res.data?.news_results ?? res.data?.organic_results ?? [];
      if (!results.length) return "No news found.";
      return results.slice(0, 5).map((r: any) => `- ${r.title}: ${r.snippet ?? ""}`).join("\n");
    } catch (e: any) {
      return `News error: ${e.message}`;
    }
  },
  {
    name: "get_news",
    description: "Get recent news headlines and updates about a company.",
    schema: z.object({ company: z.string() }),
  }
);

const tools = [getFinancials, searchWeb, getNews];
const toolNode = new ToolNode(tools);

// ─── System Prompt ───────────────────────────────────────────────
export const SYSTEM_PROMPT = `You are an expert AI Investment Research Analyst.

When given a company name, use your tools to gather REAL data, then write a structured report.

Steps:
1. Call get_financials for financial metrics
2. Call search_web for business model, competitors, strategy
3. Call get_news for recent developments
4. Synthesize into a complete report

Output format (follow exactly):

## Investment Research Report: [Company Name]
**Date:** [today] | **Analyst:** AI Research Agent (GPT-4o + LangGraph)

### 1. Company Overview
### 2. Financial Snapshot
### 3. Business Model & Products
### 4. Competitive Landscape
### 5. Recent News & Developments
### 6. SWOT Analysis
### 7. Investment Thesis

---
### 8. FINAL VERDICT

> **VERDICT: INVEST** ✅ — one-line rationale

OR > **VERDICT: WATCH** 👀 — one-line rationale

OR > **VERDICT: PASS** ❌ — one-line rationale

**Confidence:** High / Medium / Low
**Risk Level:** Low / Medium / High / Very High
**Time Horizon:** Short-term / Medium-term / Long-term`;

// ─── LangGraph ───────────────────────────────────────────────────
function shouldContinue(state: typeof AgentState.State) {
  const last = state.messages[state.messages.length - 1];
  const tc = (last as any).tool_calls;
  if (Array.isArray(tc) && tc.length > 0) return "tools";
  return END;
}

async function callModel(state: typeof AgentState.State) {
  const model = new ChatOpenAI({
    model: "gpt-4o",
    temperature: 0.2,
    apiKey: process.env.OPENAI_API_KEY,
  }).bindTools(tools);
  const response = await model.invoke(state.messages);
  return { messages: [response] };
}

const workflow = new StateGraph(AgentState)
  .addNode("agent", callModel)
  .addNode("tools", toolNode)
  .addEdge(START, "agent")
  .addConditionalEdges("agent", shouldContinue)
  .addEdge("tools", "agent");

export const graph = workflow.compile();

// ─── Public runner ───────────────────────────────────────────────
export interface LogEntry {
  role: "user" | "tool_call" | "tool_result" | "assistant";
  content: string;
  tool?: string;
}

export async function runResearchAgent(company: string): Promise<{ report: string; log: LogEntry[] }> {
  const log: LogEntry[] = [{ role: "user", content: `Research: ${company}` }];

  const initialMessages = [
    new SystemMessage(SYSTEM_PROMPT),
    new HumanMessage(`Research and generate a complete investment report with a clear INVEST/WATCH/PASS verdict: ${company}`),
  ];

  const finalState = await graph.invoke({ messages: initialMessages });

  for (const msg of finalState.messages) {
    const type = msg._getType();
    if (type === "ai") {
      const tc = (msg as any).tool_calls;
      if (tc?.length) {
        for (const call of tc) {
          log.push({ role: "tool_call", tool: call.name, content: JSON.stringify(call.args) });
        }
      }
    } else if (type === "tool") {
      log.push({
        role: "tool_result",
        tool: (msg as any).name,
        content: String((msg as any).content).slice(0, 500),
      });
    }
  }

  const report = String(finalState.messages[finalState.messages.length - 1].content);
  log.push({ role: "assistant", content: report });
  return { report, log };
}
