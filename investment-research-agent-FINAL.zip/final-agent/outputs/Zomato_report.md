## Investment Research Report: Zomato Ltd.
**Date:** 2025-06-27 | **Analyst:** AI Research Agent (GPT-4o + LangGraph)

### 1. Company Overview
Ticker: ZOMATO (NSE) | CEO: Deepinder Goyal | HQ: Gurugram | Parent: Eternal Limited (2025)

### 2. Financial Snapshot
Market Cap: ~$26B | Revenue FY2025: ~₹17,000cr | Cash: ₹12,000cr | GOV: ₹90,000cr+

### 3. Business Model
Food delivery (commission 18-25%), Blinkit QC (1,000+ dark stores), Hyperpure B2B, District events.

### 4. Competitive Landscape
Swiggy (direct rival), Zepto ($1B+ raised), BigBasket/Tata. Moat: 55%+ food delivery share, Blinkit density.

### 5. Recent News
Rebranded to Eternal Ltd (Mar 2025). Blinkit crossed 1,000 stores. First PAT-positive quarter Q2 FY2025.

### 6. SWOT
Strengths: Market leader, Blinkit hypergrowth, strong cash
Weaknesses: Cash burn at Blinkit, Tier-1 dependent
Opportunities: Food delivery <5% penetrated in India, QC expansion
Threats: Zepto aggression, Swiggy post-IPO, gig worker regulation

### 7. Investment Thesis
Profitability inflection confirmed. Blinkit = real story. QC could exceed food delivery in India in 5 years.

---
### 8. FINAL VERDICT
> **VERDICT: INVEST** ✅ — Profitability inflection + Blinkit hypergrowth = India's best consumer internet bet; accept volatility for 3-5 year horizon.

**Confidence:** Medium | **Risk Level:** High | **Time Horizon:** Long-term
