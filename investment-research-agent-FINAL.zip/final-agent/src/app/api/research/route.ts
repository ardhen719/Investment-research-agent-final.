import { NextRequest, NextResponse } from "next/server";
import { runResearchAgent } from "@/lib/agent";

export async function POST(req: NextRequest) {
  try {
    const { company } = await req.json();

    if (!company || typeof company !== "string") {
      return NextResponse.json({ error: "Company name is required" }, { status: 400 });
    }

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "OPENAI_API_KEY not configured" }, { status: 500 });
    }

    const { report, log } = await runResearchAgent(company.trim());
    return NextResponse.json({ report, log, company });
  } catch (error: any) {
    console.error("Agent error:", error);
    return NextResponse.json({ error: error.message ?? "Research failed" }, { status: 500 });
  }
}
