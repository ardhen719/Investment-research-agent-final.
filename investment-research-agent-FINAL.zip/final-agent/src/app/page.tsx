"use client";
import { useState } from "react";

interface LogEntry {
  role: string;
  content: string;
  tool?: string;
}

interface ResearchResult {
  company: string;
  report: string;
  log: LogEntry[];
  verdict: "INVEST" | "WATCH" | "PASS" | null;
}

function parseVerdict(report: string): "INVEST" | "WATCH" | "PASS" | null {
  if (/VERDICT:\s*INVEST/i.test(report)) return "INVEST";
  if (/VERDICT:\s*WATCH/i.test(report)) return "WATCH";
  if (/VERDICT:\s*PASS/i.test(report)) return "PASS";
  return null;
}

function parseMarkdown(md: string): string {
  return md
    .replace(/^### (.+)$/gm, "<h3>$1</h3>")
    .replace(/^## (.+)$/gm, "<h2>$1</h2>")
    .replace(/^> (.+)$/gm, "<blockquote>$1</blockquote>")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/^---$/gm, "<hr/>")
    .replace(/^- (.+)$/gm, "<li>$1</li>")
    .replace(/(<li>.*<\/li>\n?)+/g, (m) => `<ul>${m}</ul>`)
    .replace(/\n\n/g, "</p><p>")
    .replace(/^(?!<[hublp])(.+)$/gm, "<p>$1</p>")
    .replace(/<p><\/p>/g, "");
}

const SAMPLE_COMPANIES = ["Tesla", "Infosys", "Zomato", "Apple", "Reliance Industries", "Nvidia"];

export default function Home() {
  const [company, setCompany] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ResearchResult | null>(null);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState<"report" | "log">("report");
  const [history, setHistory] = useState<ResearchResult[]>([]);

  async function handleResearch(companyName?: string) {
    const target = companyName ?? company;
    if (!target.trim()) return;
    setLoading(true);
    setError("");
    setResult(null);
    setActiveTab("report");

    try {
      const res = await fetch("/api/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ company: target }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Research failed");

      const verdict = parseVerdict(data.report);
      const newResult: ResearchResult = { ...data, verdict };
      setResult(newResult);
      setHistory((h) => [newResult, ...h.slice(0, 4)]);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  const verdictColor = result?.verdict === "INVEST" ? "#10b981" : result?.verdict === "WATCH" ? "#f59e0b" : "#ef4444";
  const verdictIcon = result?.verdict === "INVEST" ? "✅" : result?.verdict === "WATCH" ? "👀" : "❌";

  return (
    <div style={{ minHeight: "100vh", background: "#0a0e1a" }}>
      {/* Header */}
      <header style={{ borderBottom: "1px solid #1f2d45", padding: "1rem 2rem", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
          <div style={{ width: 36, height: 36, background: "linear-gradient(135deg, #00d4aa, #3b82f6)", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>📊</div>
          <div>
            <div style={{ fontWeight: 700, fontSize: "1.1rem", color: "#f1f5f9" }}>AI Investment Research Agent</div>
            <div style={{ fontSize: "0.75rem", color: "#64748b" }}>GPT-4o · LangGraph · LangChain.js</div>
          </div>
        </div>
        <div style={{ fontSize: "0.75rem", color: "#64748b", textAlign: "right" }}>
          <div>Built by Ardhendu Shekhar</div>
          <div>InsideIIM × Altuni AI Labs</div>
        </div>
      </header>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "2rem 1.5rem" }}>
        {/* Search */}
        <div style={{ background: "#111827", border: "1px solid #1f2d45", borderRadius: 16, padding: "2rem", marginBottom: "1.5rem" }}>
          <h1 style={{ fontSize: "1.75rem", fontWeight: 800, color: "#f1f5f9", marginBottom: "0.5rem" }}>
            Company Investment Research
          </h1>
          <p style={{ color: "#64748b", marginBottom: "1.5rem" }}>
            Enter any publicly listed company. The AI agent researches financials, news, and competitive landscape — then delivers a clear <strong style={{ color: "#00d4aa" }}>INVEST / WATCH / PASS</strong> verdict.
          </p>

          <div style={{ display: "flex", gap: "0.75rem", marginBottom: "1rem" }}>
            <input
              value={company}
              onChange={(e) => setCompany(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleResearch()}
              placeholder="e.g. Tesla, Infosys, Zomato..."
              disabled={loading}
              style={{
                flex: 1, padding: "0.875rem 1.25rem", background: "#0a0e1a", border: "1px solid #1f2d45",
                borderRadius: 10, color: "#f1f5f9", fontSize: "1rem", outline: "none",
              }}
            />
            <button
              onClick={() => handleResearch()}
              disabled={loading || !company.trim()}
              style={{
                padding: "0.875rem 2rem", background: loading ? "#1f2d45" : "linear-gradient(135deg, #00d4aa, #3b82f6)",
                border: "none", borderRadius: 10, color: "#fff", fontWeight: 700, fontSize: "1rem",
                cursor: loading ? "not-allowed" : "pointer", whiteSpace: "nowrap",
              }}
            >
              {loading ? "Researching…" : "Research →"}
            </button>
          </div>

          {/* Sample chips */}
          <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
            <span style={{ fontSize: "0.8rem", color: "#64748b" }}>Try:</span>
            {SAMPLE_COMPANIES.map((c) => (
              <button
                key={c}
                onClick={() => { setCompany(c); handleResearch(c); }}
                disabled={loading}
                style={{
                  padding: "0.25rem 0.75rem", background: "#1a2235", border: "1px solid #1f2d45",
                  borderRadius: 20, color: "#93c5fd", fontSize: "0.8rem", cursor: "pointer",
                }}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Loading */}
        {loading && (
          <div style={{ background: "#111827", border: "1px solid #1f2d45", borderRadius: 16, padding: "3rem", textAlign: "center" }}>
            <div style={{ fontSize: "2.5rem", marginBottom: "1rem" }}>🔍</div>
            <div style={{ color: "#f1f5f9", fontWeight: 600, marginBottom: "0.5rem" }}>Agent is researching {company}…</div>
            <div style={{ color: "#64748b", fontSize: "0.9rem" }}>Fetching financials → Searching web → Analyzing news → Writing report</div>
            <div style={{ marginTop: "1.5rem", display: "flex", justifyContent: "center", gap: "0.5rem" }}>
              {["Fetching financials", "Searching web", "Getting news", "Generating verdict"].map((s, i) => (
                <div key={i} style={{ padding: "0.25rem 0.75rem", background: "#1a2235", border: "1px solid #1f2d45", borderRadius: 20, fontSize: "0.75rem", color: "#64748b" }}>{s}</div>
              ))}
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", borderRadius: 12, padding: "1rem 1.5rem", color: "#fca5a5" }}>
            ⚠️ {error}
          </div>
        )}

        {/* Result */}
        {result && !loading && (
          <div style={{ background: "#111827", border: "1px solid #1f2d45", borderRadius: 16, overflow: "hidden" }}>
            {/* Verdict banner */}
            {result.verdict && (
              <div style={{ background: `${verdictColor}18`, borderBottom: `2px solid ${verdictColor}`, padding: "1.25rem 2rem", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "0.75rem" }}>
                  <span style={{ fontSize: "2rem" }}>{verdictIcon}</span>
                  <div>
                    <div style={{ fontSize: "0.75rem", color: "#64748b", textTransform: "uppercase", letterSpacing: "0.1em" }}>AI Verdict for {result.company}</div>
                    <div style={{ fontSize: "1.75rem", fontWeight: 900, color: verdictColor }}>{result.verdict}</div>
                  </div>
                </div>
                <div style={{ fontSize: "0.75rem", color: "#64748b", textAlign: "right" }}>
                  <div>{result.log.filter(l => l.role === "tool_call").length} tool calls</div>
                  <div>GPT-4o · LangGraph</div>
                </div>
              </div>
            )}

            {/* Tabs */}
            <div style={{ display: "flex", borderBottom: "1px solid #1f2d45" }}>
              {(["report", "log"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  style={{
                    padding: "0.875rem 1.5rem", background: "none", border: "none",
                    borderBottom: activeTab === tab ? "2px solid #00d4aa" : "2px solid transparent",
                    color: activeTab === tab ? "#00d4aa" : "#64748b",
                    fontWeight: activeTab === tab ? 600 : 400, cursor: "pointer", textTransform: "capitalize",
                  }}
                >
                  {tab === "report" ? "📄 Report" : "🔧 Agent Log (Bonus)"}
                </button>
              ))}
            </div>

            {/* Report tab */}
            {activeTab === "report" && (
              <div className="prose" style={{ padding: "2rem" }}
                dangerouslySetInnerHTML={{ __html: parseMarkdown(result.report) }}
              />
            )}

            {/* Log tab */}
            {activeTab === "log" && (
              <div style={{ padding: "1.5rem" }}>
                <p style={{ color: "#64748b", fontSize: "0.85rem", marginBottom: "1rem" }}>
                  Full LangGraph agent execution trace — every tool call and result. Included as per bonus requirements.
                </p>
                {result.log.map((entry, i) => (
                  <div key={i} style={{
                    marginBottom: "0.75rem", padding: "0.875rem 1rem", borderRadius: 10,
                    background: entry.role === "tool_call" ? "rgba(59,130,246,0.1)" : entry.role === "tool_result" ? "rgba(0,212,170,0.08)" : entry.role === "assistant" ? "rgba(255,255,255,0.03)" : "#1a2235",
                    border: `1px solid ${entry.role === "tool_call" ? "rgba(59,130,246,0.3)" : entry.role === "tool_result" ? "rgba(0,212,170,0.2)" : "#1f2d45"}`,
                  }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.4rem" }}>
                      <span style={{ fontSize: "0.7rem", padding: "0.15rem 0.5rem", borderRadius: 4, background: "#1f2d45", color: "#93c5fd", fontWeight: 600, textTransform: "uppercase" }}>
                        {entry.role === "tool_call" ? `🔧 ${entry.tool}` : entry.role === "tool_result" ? `✅ result: ${entry.tool}` : entry.role === "assistant" ? "🤖 final report" : "👤 user"}
                      </span>
                    </div>
                    <pre style={{ fontSize: "0.8rem", color: "#94a3b8", whiteSpace: "pre-wrap", wordBreak: "break-word", maxHeight: 200, overflow: "auto" }}>
                      {entry.content.slice(0, 600)}{entry.content.length > 600 ? "…" : ""}
                    </pre>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* History */}
        {history.length > 1 && (
          <div style={{ marginTop: "1.5rem" }}>
            <div style={{ fontSize: "0.8rem", color: "#64748b", marginBottom: "0.75rem", textTransform: "uppercase", letterSpacing: "0.1em" }}>Recent Searches</div>
            <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
              {history.slice(1).map((h, i) => {
                const vc = h.verdict === "INVEST" ? "#10b981" : h.verdict === "WATCH" ? "#f59e0b" : "#ef4444";
                return (
                  <button key={i} onClick={() => setResult(h)}
                    style={{ padding: "0.5rem 1rem", background: "#111827", border: `1px solid ${vc}40`, borderRadius: 8, color: "#e2e8f0", cursor: "pointer", display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "0.85rem" }}>
                    <span style={{ color: vc, fontWeight: 700 }}>{h.verdict}</span> {h.company}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
